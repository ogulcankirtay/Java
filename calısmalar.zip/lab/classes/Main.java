package lab_7;

/**
 *
 * @author asayar
 */
public class Main {

}
