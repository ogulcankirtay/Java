
package lab_7;

/**
 *
 * @author asayar
 */
public class Faktoriyal {
    
    private int deger;
    private int sonuc;
    
    /**
     * Faktoriyali bulunmak istenen
     * değeri atar
     * @param deger
     */
    public void setDeger(int deger){
        
    }
    /**
     * Faktoriyali bulunmak istenen
     * dönderir
     * @return
     */
    public int getDeger(){
        
        return 0;
    }
    
    /** 
     * Girilen değerin faktorial değerini Islemlerim
     * class ındaki methodları kullanarak 
     * hesaplayıp sonuc parametresine yazdırır
     */    
    public void hesapla(){
        
    }
    
    /**
     * Degeri ve sonucu ekrana yazdırır
     */
    public void ekranaYazdir(){        
     
    }

}
