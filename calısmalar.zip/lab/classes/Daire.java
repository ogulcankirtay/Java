
package lab_7;

/**
 *
 * @author asayar
 */
public class Daire {
    
    // Class parametreleri
    public double PI=3.14;
    public int yaricap;
    
    /**
     * Constructor
     * @param yaricap Dairenin yarıçapı
     */
    public Daire(int yaricap){
        
    }
    
    /**
     * Dairenin alanını Islemlerim class ındaki 
     * methodları kullanarak hesaplar
     * @return alanı double cinsinden dondurur
     */
    public double  alanHesapla(){
        
        return 0.0;
    }
    
    /**
     * Dairenin çevresini Islemlerim class ındaki 
     * methodları kullanarak hesaplar
     * @return cevreyi double cinsinden dondurur
     */
    public double cevreHesapla(){
        
        return 0.0;
    }
    
    /**
     * Bir dairenin cevresinin alanından büyüyk
     * olup olmadığını Islemlerim class ındaki 
     * methodları kullanarak belirler
     * @return boolean değer dönderir
     */
    public boolean cevreAlandanBuyuktur(){
        
        return false;
    }
    
    /**
     * Bir dairenin cevresinin alanından küçük
     * olup olmadığını ıslemlerim class ındaki 
     * methodları kullanarak belirler
     * @return boolean değer dönderir
     */
    public boolean cevreAlandanKucuktur(){
        
        
        return false;
    }
    
    /**
     * Dairenin alanını ve çevresini ekrana yazdırır.
     */
    public void ekranaYazdir(){
        
    }
    
    

}
