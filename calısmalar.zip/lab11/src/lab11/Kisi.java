//Oğulcan Kırtay 190202005
package lab11;

/**
 *
 * @author ASUS*/

interface  Kisi {
    public String isim();
}
