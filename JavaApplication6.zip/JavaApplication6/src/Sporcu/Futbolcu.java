package Sporcu;

public class Futbolcu extends Sporcu {

    public boolean kartKullanildiMi;
    private int penalti, serbestVurus, kaleciKarsiKarsiya;

    public Futbolcu() {

        this.penalti = 0;
        this.serbestVurus = 0;
        this.kaleciKarsiKarsiya = 0;
    }

    public Futbolcu(int penalti, int serbestAtis, int kaleciKarsiKarsiya, String FutbolcuAdi, String FutbolcuTakim) {
        super(FutbolcuAdi, FutbolcuTakim);
        this.penalti = penalti;
        this.serbestVurus = serbestAtis;
        this.kaleciKarsiKarsiya = kaleciKarsiKarsiya;
    }

    public int getPenalti() {
        return penalti;
    }

    public void setPenalti(int penalti) {
        this.penalti = penalti;
    }

    public int getSerbestVurus() {
        return serbestVurus;
    }

    public void setSerbestVurus(int serbestVurus) {
        this.serbestVurus = serbestVurus;
    }

    public int getKaleciKarsiKarsiya() {
        return kaleciKarsiKarsiya;
    }

    public void setKaleciKarsiKarsiya(int kaleciKarsiKarsiya) {
        this.kaleciKarsiKarsiya = kaleciKarsiKarsiya;
    }

    public String getSporcuİsim() {
        return Sporcuİsim;
    }

    public void setSporcuİsim(String Sporcuİsim) {
        this.Sporcuİsim = Sporcuİsim;
    }

    @Override
    public int sporcuPuaniGoster() {
        return super.sporcuPuaniGoster();
    }

    public void kullan() {
        this.kartKullanildiMi = true;
    }

    /**
     *
     * @param i
     */
    public void setpenalti() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setSporcuIsmi(String ronaldo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
