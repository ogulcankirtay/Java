import Sporcu.*;
import test.masa;
public class Test {

    public static void main(String[] args) {
   
   masa anamenu=new masa();
     anamenu.setVisible(true);
    }

   

}
