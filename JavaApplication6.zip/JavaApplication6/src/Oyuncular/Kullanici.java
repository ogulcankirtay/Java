package Oyuncular;

import Sporcu.Sporcu;

public class Kullanici extends Oyuncu
{
	public Kullanici()
	{
		super(0, "Kullanıcı", 0);
	}

	public Kullanici(int oyuncuID, String oyuncuAdi, int Skor)
	{
		super(oyuncuID, oyuncuAdi, Skor);
	}

	@Override
	public Sporcu kartSec(Sporcu kart)
	{
		this.kartKullan(kart);

		return kart;
	}

    private void kartKullan(Sporcu kart) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}