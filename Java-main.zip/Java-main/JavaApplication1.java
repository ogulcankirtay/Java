/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author ASUS
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Merhaba Dünya");
        System.out.println("Oğulcan Kırtay");
        // ::java tek satırlık yorum satırı::
        /* ::java 
        çok
        satırlık 
        yorum 
        satırı::
        */
        int x;
        x=5;
        int y=10;
        System.out.println("integer x değişkenini değeri "+ x);
        float pi =(float) 3.14;
        double dpi=3.14;
        String s="benim adım Oğulcan Kırtay";
        System.out.println("string : "+s+"float pi: " +pi+"double dpi "+dpi);
        
    }
    
}
